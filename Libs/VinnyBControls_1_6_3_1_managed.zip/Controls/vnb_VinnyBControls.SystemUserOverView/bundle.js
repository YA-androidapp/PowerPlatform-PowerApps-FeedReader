var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./SystemUserOverView/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./SystemUserOverView/EntityReference.ts":
/*!***********************************************!*\
  !*** ./SystemUserOverView/EntityReference.ts ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar EntityReference =\n/** @class */\nfunction () {\n  function EntityReference(LogicalName, Id, Name) {\n    this.LogicalName = LogicalName;\n    this.Id = Id;\n    this.Name = Name;\n  }\n\n  EntityReference.prototype.ToXrmLookupValue = function () {\n    var thisEntityRecord = {\n      entityType: this.LogicalName,\n      id: this.Id,\n      name: this.Name\n    };\n    return thisEntityRecord;\n  };\n\n  return EntityReference;\n}();\n\nexports.EntityReference = EntityReference;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./SystemUserOverView/EntityReference.ts?");

/***/ }),

/***/ "./SystemUserOverView/SystemUser.ts":
/*!******************************************!*\
  !*** ./SystemUserOverView/SystemUser.ts ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar SystemUser =\n/** @class */\nfunction () {\n  function SystemUser(PhotoUrl, Id, Name, Telephone, Mobile, Email, JobTitle, Position, BusinessUnit, Parent) {\n    this.PhotoUrl = PhotoUrl;\n    this.Id = Id;\n    this.Name = Name;\n    this.Telephone = Telephone;\n    this.Mobile = Mobile;\n    this.Email = Email;\n    this.JobTitle = JobTitle;\n    this.Position = Position;\n    this.BusinessUnit = BusinessUnit;\n    this.Parent = Parent;\n  }\n\n  SystemUser.prototype.ToXrmLookupValue = function () {\n    var thisEntityRecord = {\n      entityType: \"systemuser\",\n      id: this.Id,\n      name: this.Name\n    };\n    return thisEntityRecord;\n  };\n\n  SystemUser.prototype.ToXrmActivityPartyValue = function () {\n    var thisEntityRecord = [{\n      entityType: \"systemuser\",\n      id: this.Id,\n      name: this.Name\n    }];\n    return thisEntityRecord;\n  };\n\n  return SystemUser;\n}();\n\nexports.SystemUser = SystemUser;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./SystemUserOverView/SystemUser.ts?");

/***/ }),

/***/ "./SystemUserOverView/index.ts":
/*!*************************************!*\
  !*** ./SystemUserOverView/index.ts ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar SystemUser_1 = __webpack_require__(/*! ./SystemUser */ \"./SystemUserOverView/SystemUser.ts\");\n\nvar EntityReference_1 = __webpack_require__(/*! ./EntityReference */ \"./SystemUserOverView/EntityReference.ts\");\n\nvar SystemUserOverView =\n/** @class */\nfunction () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function SystemUserOverView() {\n    this._systemUsers = new Array();\n  }\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='starndard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  SystemUserOverView.prototype.init = function (context, notifyOutputChanged, state, container) {\n    //Form Type\n    this._formType = Xrm.Page.ui.getFormType();\n\n    if (this._formType != 1\n    /* Create */\n    ) {\n        //Record Id\n        this._thisEntity = new EntityReference_1.EntityReference(Xrm.Page.data.entity.getEntityName(), Xrm.Page.data.entity.getId(), Xrm.Page.data.entity.getPrimaryAttributeValue());\n      } //Activity Parameters\n\n\n    this.JsonIsValid(context);\n    this._container = document.createElement(\"div\");\n\n    this._container.setAttribute(\"class\", \"Container\");\n\n    container.append(this._container); //Buttons\n\n    this._buttons = document.createElement(\"div\");\n\n    this._buttons.setAttribute(\"class\", \"SelectorTab\");\n\n    container.append(this._buttons); //Users\n\n    this._divSystemUsers = document.createElement(\"div\");\n    container.append(this._divSystemUsers);\n    this.GetAttributeValue();\n  };\n\n  SystemUserOverView.prototype.JsonIsValid = function (context) {\n    try {\n      this._activitiesReference = JSON.parse(context.parameters.json.raw);\n    } catch (e) {\n      Xrm.Utility.alertDialog(\"Verify the parameter activity manifest.\", function () {});\n    }\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  SystemUserOverView.prototype.updateView = function (context) {// Add code to update control view\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  SystemUserOverView.prototype.getOutputs = function () {\n    return {};\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  SystemUserOverView.prototype.destroy = function () {// Add code to cleanup control if necessary\n  };\n  /**\r\n   * Recursive: Workaround, while we don't have a Lookup field on PCF\r\n   */\n\n\n  SystemUserOverView.prototype.GetAttributeValue = function () {\n    var ownerAttribute = Xrm.Page.getAttribute(\"ownerid\");\n\n    if (ownerAttribute) {\n      //Get Value\n      var ownerValue = ownerAttribute.getValue();\n\n      if (ownerValue[0]) {\n        if (ownerValue[0].entityType = \"systemuser\") this.RetrieveSystemUser(ownerValue[0].id, this);else return;\n      } else {\n        //Recursive\n        this.GetAttributeValue();\n      }\n    } else return;\n  };\n  /**\r\n   * Retrieve informations about SystemUser\r\n   * @param systemUserId\r\n   * @param self\r\n   */\n\n\n  SystemUserOverView.prototype.RetrieveSystemUser = function (systemUserId, self) {\n    if (!self) self = this;\n    Xrm.WebApi.online.retrieveRecord(\"systemuser\", systemUserId, \"?$select=address1_telephone1,_businessunitid_value,fullname,internalemailaddress,jobtitle,mobilephone,_parentsystemuserid_value,entityimageid,_positionid_value\").then(function success(result) {\n      var fullname = result[\"fullname\"];\n      var address1_telephone1 = result[\"address1_telephone1\"];\n      var mobilephone = result[\"mobilephone\"];\n      var internalemailaddress = result[\"internalemailaddress\"];\n      var jobtitle = result[\"jobtitle\"]; //Picture\n\n      var entityimageid = result[\"entityimageid\"];\n      var entityimageurl = \"\";\n      if (entityimageid) entityimageurl = Xrm.Page.context.getClientUrl() + result[\"entityimage_url\"]; //BusinessUnit\n\n      var businessUnit = new EntityReference_1.EntityReference(\"\", \"\", \"\");\n\n      if (result[\"_businessunitid_value\"]) {\n        businessUnit = new EntityReference_1.EntityReference(result[\"_businessunitid_value@Microsoft.Dynamics.CRM.lookuplogicalname\"], result[\"_businessunitid_value\"], result[\"_businessunitid_value@OData.Community.Display.V1.FormattedValue\"]);\n      } //Position\n\n\n      var postion = new EntityReference_1.EntityReference(\"\", \"\", \"\");\n\n      if (result[\"_positionid_value\"]) {\n        postion = new EntityReference_1.EntityReference(result[\"_positionid_value@Microsoft.Dynamics.CRM.lookuplogicalname\"], result[\"_positionid_value\"], result[\"_positionid_value@OData.Community.Display.V1.FormattedValue\"]);\n      } //Parent\n\n\n      var parent = new EntityReference_1.EntityReference(\"\", \"\", \"\");\n\n      if (result[\"_parentsystemuserid_value\"]) {\n        parent = new EntityReference_1.EntityReference(result[\"_parentsystemuserid_value@Microsoft.Dynamics.CRM.lookuplogicalname\"], result[\"_parentsystemuserid_value\"], result[\"_parentsystemuserid_value@OData.Community.Display.V1.FormattedValue\"]);\n      }\n\n      var systemUser;\n      systemUser = new SystemUser_1.SystemUser(entityimageurl, systemUserId, fullname, address1_telephone1, mobilephone, internalemailaddress, jobtitle, postion, businessUnit, parent);\n\n      self._systemUsers.push(systemUser);\n\n      self.CreateContent(systemUser); //Recursive\n\n      if (systemUser.Parent.Id) self.RetrieveSystemUser(systemUser.Parent.Id, self);\n    }, function (error) {\n      Xrm.Utility.alertDialog(error.message, function () {});\n    });\n  };\n  /**\r\n   * Create visual components to represent the SystemUser\r\n   * @param systemUser\r\n   */\n\n\n  SystemUserOverView.prototype.CreateContent = function (systemUser) {\n    //Button\n    var selector;\n    selector = document.createElement(\"button\");\n    selector.setAttribute(\"class\", \"SelectorButton\");\n    selector.innerText = systemUser.Name;\n    selector.addEventListener(\"click\", this.SelectUser.bind(this, systemUser.Id));\n\n    this._buttons.append(selector); //User\n\n\n    var divContent;\n    divContent = document.createElement(\"div\");\n    divContent.setAttribute(\"class\", \"Content\");\n    divContent.id = systemUser.Id;\n\n    this._divSystemUsers.append(divContent); //Left\n\n\n    var divLeft;\n    divLeft = document.createElement(\"div\");\n    divLeft.setAttribute(\"class\", \"Left\");\n    divContent.append(divLeft);\n    {\n      //Image\n      var img = void 0;\n      img = document.createElement(\"img\");\n      img.setAttribute(\"class\", \"Image\");\n      img.setAttribute(\"src\", systemUser.PhotoUrl);\n      divLeft.append(img);\n    } //Right\n\n    var divRight;\n    divRight = document.createElement(\"div\");\n    divRight.setAttribute(\"class\", \"Right\");\n    divContent.append(divRight);\n    {\n      //Name\n      var pName = void 0;\n      pName = document.createElement(\"p\");\n      pName.innerText = systemUser.Name;\n      divRight.append(pName); //Telephone\n\n      var aTelephone = void 0;\n      aTelephone = document.createElement(\"a\");\n      aTelephone.setAttribute(\"href\", \"tel:\" + systemUser.Telephone);\n      aTelephone.innerText = systemUser.Telephone;\n      divRight.append(aTelephone); //MobilePhone\n\n      var aMobilePhone = void 0;\n      aMobilePhone = document.createElement(\"a\");\n      aMobilePhone.setAttribute(\"href\", \"tel:\" + systemUser.Mobile);\n      aMobilePhone.innerText = systemUser.Mobile;\n      divRight.append(aMobilePhone); //Email\n\n      var aEmail = void 0;\n      aEmail = document.createElement(\"a\");\n      aEmail.setAttribute(\"href\", \"mailto:\" + systemUser.Email);\n      aEmail.innerText = systemUser.Email;\n      divRight.append(aEmail); //JobTitle\n\n      var pJobTitle = void 0;\n      pJobTitle = document.createElement(\"p\");\n      pJobTitle.innerText = systemUser.JobTitle;\n      divRight.append(pJobTitle); //Position\n\n      var pPosition = void 0;\n      pPosition = document.createElement(\"p\");\n      pPosition.innerText = systemUser.Position.Name;\n      divRight.append(pPosition); //Position\n\n      var pBusinessUnit = void 0;\n      pBusinessUnit = document.createElement(\"p\");\n      pBusinessUnit.innerText = systemUser.BusinessUnit.Name;\n      divRight.append(pBusinessUnit); //Activities Buttons\n\n      divRight.append(this.CreateActivityArea());\n    }\n  };\n  /**\r\n   * Dynamic components, based on JSON parameter. Add a button for each record.\r\n   */\n\n\n  SystemUserOverView.prototype.CreateActivityArea = function () {\n    var divActivities;\n    divActivities = document.createElement(\"div\");\n    divActivities.setAttribute(\"class\", \"Activities\"); //Only for created records\n\n    if (this._formType != 1\n    /* Create */\n    && this._activitiesReference && this._activitiesReference.length > 0) {\n      for (var index = 0; index < this._activitiesReference.length; index++) {\n        //Get Acitivity\n        var activityReference = this._activitiesReference[index]; //Create a button for the activity\n\n        divActivities.append(this.CreateActivityButton(activityReference));\n      }\n    }\n\n    return divActivities;\n  };\n  /**\r\n   * Create a User Name\r\n   * @param systemUserId\r\n   */\n\n\n  SystemUserOverView.prototype.SelectUser = function (systemUserId) {\n    var contents;\n    contents = document.getElementsByClassName(\"Content\");\n\n    for (var index = 0; index < contents.length; index++) {\n      var element = contents[index];\n      element.style.display = \"none\";\n    }\n\n    var systemUserContent = document.getElementById(systemUserId);\n    systemUserContent.style.display = \"flex\"; //Get SystemUserReferemce in memory array\n\n    this.GetSystemUserReference(systemUserId);\n  };\n  /**\r\n   * Select SystemUser by SystemUserId\r\n  */\n\n\n  SystemUserOverView.prototype.GetSystemUserReference = function (systemUserId) {\n    //Verify if the array has values\n    if (this._systemUsers.length > 0) this._selectedSystemUser = this._systemUsers.filter(function (systemUser) {\n      return systemUser.Id == systemUserId;\n    })[0];\n  };\n  /**\r\n   * Create a button to represent the activity\r\n   * @param activityReference\r\n   */\n\n\n  SystemUserOverView.prototype.CreateActivityButton = function (activityReference) {\n    var btnActivity;\n    btnActivity = document.createElement(\"button\");\n    btnActivity.setAttribute(\"class\", \"Activities\");\n    btnActivity.innerText = activityReference.DisplayName;\n    btnActivity.addEventListener(\"click\", this.NewActvitiy.bind(this, activityReference.LogicalName));\n    return btnActivity;\n  };\n  /**\r\n   * Call a new activity form\r\n   * @param activityLogicalName\r\n   */\n\n\n  SystemUserOverView.prototype.NewActvitiy = function (activityLogicalName) {\n    if (this._formType != 1\n    /* Create */\n    ) {\n        var parameters = {\n          \"regardingobjectid\": this._thisEntity.ToXrmLookupValue(),\n          \"ownerid\": this._selectedSystemUser.ToXrmLookupValue()\n        };\n        Xrm.Utility.openQuickCreate(activityLogicalName, this._thisEntity.ToXrmLookupValue(), parameters).then(function (caller) {}, function (error) {});\n      }\n  };\n\n  return SystemUserOverView;\n}();\n\nexports.SystemUserOverView = SystemUserOverView;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./SystemUserOverView/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('VinnyBControls.SystemUserOverView', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.SystemUserOverView);
} else {
	var VinnyBControls = VinnyBControls || {};
	VinnyBControls.SystemUserOverView = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.SystemUserOverView;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}