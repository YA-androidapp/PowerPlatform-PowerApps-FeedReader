var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./NNTags/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./NNTags/index.ts":
/*!*************************!*\
  !*** ./NNTags/index.ts ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar NNTags =\n/** @class */\nfunction () {\n  function NNTags() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='starndard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  NNTags.prototype.init = function (context, notifyOutputChanged, state, container) {\n    if (Xrm.Page.ui.getFormType() == 1\n    /* Create */\n    ) return; //Core\n\n    this._entityLogicalName = Xrm.Page.data.entity.getEntityName();\n    this._entitySetName = this.RetrieveEntityMetada(this._entityLogicalName);\n    this._entityId = Xrm.Page.data.entity.getId().replace(\"{\", \"\").replace(\"}\", \"\");\n    this._relationShipName = context.parameters.relationship_name.raw;\n    this._relatedEntityLogicalName = context.parameters.dataSet.getTargetEntityType();\n    this._relatedEntitySetName = this.RetrieveEntityMetada(this._relatedEntityLogicalName); //Background Colors\n\n    this._associatedHex = context.parameters.associated_hex.raw; //Filter\n\n    this._filter = document.createElement(\"input\");\n\n    this._filter.setAttribute(\"type\", \"text\");\n\n    this._filter.style.width = \"95%\";\n\n    this._filter.addEventListener(\"keyup\", this.FilterTags.bind(this));\n\n    container.append(this._filter); //Main div\n\n    this._container = document.createElement(\"div\");\n\n    this._container.setAttribute(\"class\", \"Container\");\n\n    container.append(this._container);\n  };\n  /**\r\n   * Filter Tags\r\n   */\n\n\n  NNTags.prototype.FilterTags = function () {\n    var values = document.getElementsByTagName(\"p\");\n    var matchTags = new Array();\n    var unmatchTags = new Array();\n\n    var _loop_1 = function _loop_1(index) {\n      var element = values[index];\n      var p = element;\n      var contains = p.textContent.toUpperCase().indexOf(this_1._filter.value.toUpperCase());\n      var parent_1 = p.parentElement;\n\n      if (this_1._filter.value != \"\") {\n        if (parent_1 != null && parent_1.tagName == \"BUTTON\" && parent_1.className == \"Unassociated\") {\n          if (contains > -1) {\n            matchTags.push(parent_1);\n          } else if (matchTags.filter(function (button) {\n            return button.id == parent_1.id;\n          }).length == 0) {\n            unmatchTags.push(parent_1);\n          }\n        }\n      } else matchTags.push(parent_1);\n    };\n\n    var this_1 = this;\n\n    for (var index = 0; index < values.length; index++) {\n      _loop_1(index);\n    }\n\n    for (var index = 0; index < matchTags.length; index++) {\n      var element = matchTags[index];\n      var parent_2 = element.parentElement;\n      parent_2.append(element);\n      this.VisibleTag(element);\n    }\n\n    for (var index = 0; index < unmatchTags.length; index++) {\n      var element = unmatchTags[index];\n      var parent_3 = element.parentElement;\n      parent_3.append(element);\n      this.CollapseTag(element);\n    }\n  };\n\n  NNTags.prototype.CollapseTag = function (tagButton) {\n    tagButton.style.visibility = \"collapse\";\n  };\n\n  NNTags.prototype.VisibleTag = function (tagButton) {\n    tagButton.style.visibility = \"visible\";\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  NNTags.prototype.updateView = function (context) {\n    if (Xrm.Page.ui.getFormType() == 1\n    /* Create */\n    ) return; //If the view is loaded\n\n    if (!context.parameters.dataSet.loading) {\n      var columns = this.GetColumns(context);\n      this.ClearContainer();\n      this.CreateButtonTag(context, columns);\n      this.RetrieveMultipleManyToManyRelationships();\n    }\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  NNTags.prototype.getOutputs = function () {\n    return {};\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  NNTags.prototype.destroy = function () {// Add code to cleanup control if necessary\n  };\n  /**\r\n   * Create a button to represents the record\r\n   * @param context\r\n   * @param columns\r\n   */\n\n\n  NNTags.prototype.CreateButtonTag = function (context, columns) {\n    if (context.parameters.dataSet.sortedRecordIds.length > 0) {\n      var _loop_2 = function _loop_2(recordId) {\n        var self_1 = this_2; //Create a button\n\n        var buttonRecord;\n        buttonRecord = document.createElement(\"button\");\n        buttonRecord.setAttribute(\"associated\", false.toString());\n        buttonRecord.setAttribute(\"clicked\", false.toString());\n        buttonRecord.setAttribute(\"class\", \"Unassociated\");\n        buttonRecord.id = recordId.toString();\n        buttonRecord.addEventListener(\"click\", this_2.ExecuteRequest.bind(this_2, self_1, buttonRecord)); //Columns in view / value\n\n        columns.forEach(function (column, index) {\n          var attributeValue = document.createElement(\"p\");\n          attributeValue.textContent = context.parameters.dataSet.records[recordId].getFormattedValue(column.name);\n          buttonRecord.append(attributeValue);\n        }); //Append record to container\n\n        this_2._container.append(buttonRecord);\n      };\n\n      var this_2 = this; //Record\n\n      for (var _i = 0, _a = context.parameters.dataSet.sortedRecordIds; _i < _a.length; _i++) {\n        var recordId = _a[_i];\n\n        _loop_2(recordId);\n      }\n    }\n  };\n  /**\r\n   * Retrieve all columns in the view\r\n   * @param context\r\n   */\n\n\n  NNTags.prototype.GetColumns = function (context) {\n    //alert(context.parameters.dataSet.columns.length);\n    //No columns\n    if (!context.parameters.dataSet.columns && context.parameters.dataSet.columns.length === 0) {\n      return [];\n    }\n\n    var columns = context.parameters.dataSet.columns.filter(function (columnItem) {\n      return columnItem.order >= 0;\n    }); // Sort those columns so that they will be rendered in order\n\n    columns.sort(function (a, b) {\n      return a.order - b.order;\n    });\n    return columns;\n  };\n  /**\r\n  * Action executed by record button\r\n  * @param caller\r\n  * @param button\r\n  */\n\n\n  NNTags.prototype.ExecuteRequest = function (caller, button) {\n    var clicked = button.getAttribute(\"clicked\"); //Prevent multiple clicks\n\n    if (false.toString() == clicked) {\n      //Lock\n      button.setAttribute(\"clicked\", true.toString());\n      var associated = button.getAttribute(\"associated\");\n      if (true.toString() == associated) this.DisassociateRequest(caller, button);else this.AssociateRequest(caller, button);\n    }\n  };\n  /**\r\n   * Associate the records\r\n   * @param caller\r\n   * @param button\r\n   */\n\n\n  NNTags.prototype.AssociateRequest = function (caller, button) {\n    var association = {\n      \"@odata.id\": Xrm.Page.context.getClientUrl() + \"/api/data/v9.1/\" + this._relatedEntitySetName + \"(\" + button.id + \")\"\n    };\n    var req = new XMLHttpRequest();\n    req.open(\"POST\", Xrm.Page.context.getClientUrl() + \"/api/data/v9.1/\" + this._entitySetName + \"(\" + this._entityId + \")/\" + this._relationShipName + \"/$ref\", true);\n    req.setRequestHeader(\"Accept\", \"application/json\");\n    req.setRequestHeader(\"Content-Type\", \"application/json; charset=utf-8\");\n    req.setRequestHeader(\"OData-MaxVersion\", \"4.0\");\n    req.setRequestHeader(\"OData-Version\", \"4.0\");\n\n    req.onreadystatechange = function () {\n      if (this.readyState === 4) {\n        req.onreadystatechange = null;\n\n        if (this.status === 204 || this.status === 1223) {\n          caller.RecordAssociated(button);\n          button.setAttribute(\"clicked\", false.toString());\n        } else {\n          Xrm.Utility.alertDialog(this.statusText, function () {});\n          button.setAttribute(\"clicked\", false.toString());\n        }\n      }\n    };\n\n    req.send(JSON.stringify(association));\n  };\n  /**\r\n   * Diassociate the records\r\n   * @param caller\r\n   * @param button\r\n   */\n\n\n  NNTags.prototype.DisassociateRequest = function (caller, button) {\n    var req = new XMLHttpRequest();\n    req.open(\"DELETE\", Xrm.Page.context.getClientUrl() + \"/api/data/v9.1/\" + this._entitySetName + \"(\" + this._entityId + \")/\" + this._relationShipName + \"(\" + button.id + \")/$ref\", true);\n    req.setRequestHeader(\"Accept\", \"application/json\");\n    req.setRequestHeader(\"Content-Type\", \"application/json; charset=utf-8\");\n    req.setRequestHeader(\"OData-MaxVersion\", \"4.0\");\n    req.setRequestHeader(\"OData-Version\", \"4.0\");\n\n    req.onreadystatechange = function () {\n      if (this.readyState === 4) {\n        req.onreadystatechange = null;\n\n        if (this.status === 204 || this.status === 1223) {\n          caller.RecordDisassociated(button);\n          button.setAttribute(\"clicked\", false.toString());\n        } else {\n          button.setAttribute(\"clicked\", false.toString());\n          Xrm.Utility.alertDialog(this.statusText, function () {});\n        }\n      }\n    };\n\n    req.send();\n  };\n  /**\r\n   * Retrieve and flag (change color) all related records\r\n   */\n\n\n  NNTags.prototype.RetrieveMultipleManyToManyRelationships = function () {\n    var self = this;\n    Xrm.WebApi.online.retrieveMultipleRecords(this._relationShipName, \"?$select=\" + this._relatedEntityLogicalName + \"id&$filter=\" + this._entityLogicalName + \"id eq \" + this._entityId).then(function success(results) {\n      for (var i = 0; i < results.entities.length; i++) {\n        var buttonRecord = document.getElementById(results.entities[i][self._relatedEntityLogicalName + \"id\"].replace(\"{\", \"\").replace(\"}\", \"\"));\n        if (buttonRecord) self.RecordAssociated(buttonRecord);\n      }\n    }, function (error) {\n      Xrm.Utility.alertDialog(error.message, function () {});\n      return [];\n    });\n  };\n  /**\r\n   * Retrieve EntitySetName\r\n   * @param entityLogicalName\r\n   */\n\n\n  NNTags.prototype.RetrieveEntityMetada = function (entityLogicalName) {\n    var entitySet;\n    entitySet = \"\";\n    var req = new XMLHttpRequest();\n    req.open(\"GET\", Xrm.Page.context.getClientUrl() + \"/api/data/v9.1/\" + \"EntityDefinitions(LogicalName='\" + entityLogicalName + \"')?$select=EntitySetName\", false);\n    req.setRequestHeader(\"Accept\", \"application/json\");\n    req.setRequestHeader(\"Content-Type\", \"application/json; charset=utf-8\");\n    req.setRequestHeader(\"OData-MaxVersion\", \"4.0\");\n    req.setRequestHeader(\"OData-Version\", \"4.0\");\n\n    req.onreadystatechange = function () {\n      if (this.readyState === 4) {\n        req.onreadystatechange = null;\n\n        if (this.status === 200) {\n          var result = JSON.parse(this.response);\n          entitySet = result.EntitySetName;\n        } else {\n          entitySet = \"\";\n        }\n      }\n    };\n\n    req.send();\n    return entitySet;\n  };\n  /**\r\n   * Change the color for Associated\r\n   * @param button\r\n   */\n\n\n  NNTags.prototype.RecordAssociated = function (button) {\n    button.setAttribute(\"associated\", true.toString());\n    button.style.backgroundColor = this._associatedHex;\n  };\n  /**\r\n   * Change the color for Disassoaciated\r\n   * @param button\r\n   */\n\n\n  NNTags.prototype.RecordDisassociated = function (button) {\n    button.setAttribute(\"associated\", false.toString());\n    button.style.backgroundColor = null;\n  };\n  /**\r\n   * Clear all components in main container\r\n   */\n\n\n  NNTags.prototype.ClearContainer = function () {\n    while (this._container.firstChild) {\n      this._container.removeChild(this._container.firstChild);\n    }\n  };\n\n  return NNTags;\n}();\n\nexports.NNTags = NNTags;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./NNTags/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('VinnyBComponents.NNTags', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.NNTags);
} else {
	var VinnyBComponents = VinnyBComponents || {};
	VinnyBComponents.NNTags = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.NNTags;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}