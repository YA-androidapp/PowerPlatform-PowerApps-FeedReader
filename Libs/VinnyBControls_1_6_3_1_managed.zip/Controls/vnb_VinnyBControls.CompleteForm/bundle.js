var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./CompleteForm/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./CompleteForm/index.ts":
/*!*******************************!*\
  !*** ./CompleteForm/index.ts ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar CompleteForm =\n/** @class */\nfunction () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function CompleteForm() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  CompleteForm.prototype.init = function (context, notifyOutputChanged, state, container) {\n    this.GetAttributes(); //Render HTML\n\n    this._container = document.createElement(\"div\");\n    container.append(this._container); //Main\n\n    this.RenderHTML();\n    this.AssociateValues();\n  };\n\n  CompleteForm.prototype.GetAttributes = function () {\n    this._noneNulls = Xrm.Page.getAttribute().filter(function (f) {\n      return f.getRequiredLevel() == \"none\" && !f.getValue();\n    });\n    this._noneNotNulls = Xrm.Page.getAttribute().filter(function (f) {\n      return f.getRequiredLevel() == \"none\" && f.getValue();\n    });\n    this._recommendedNulls = Xrm.Page.getAttribute().filter(function (f) {\n      return f.getRequiredLevel() == \"recommended\" && !f.getValue();\n    });\n    this._recommendedNotNulls = Xrm.Page.getAttribute().filter(function (f) {\n      return f.getRequiredLevel() == \"recommended\" && f.getValue();\n    });\n    this._requiredNulls = Xrm.Page.getAttribute().filter(function (f) {\n      return f.getRequiredLevel() == \"required\" && !f.getValue();\n    });\n    this._requiredNotNulls = Xrm.Page.getAttribute().filter(function (f) {\n      return f.getRequiredLevel() == \"required\" && f.getValue();\n    });\n  };\n\n  CompleteForm.prototype.RenderHTML = function () {\n    // %\n    this._geralPercentLabel = document.createElement(\"label\");\n\n    this._container.append(this._geralPercentLabel); //Required Levels\n\n\n    this._percentsDiv = document.createElement(\"div\");\n\n    this._container.append(this._percentsDiv);\n\n    {\n      //None\n      this._noneDiv = document.createElement(\"div\");\n\n      this._noneDiv.setAttribute(\"class\", \"divNone\");\n\n      this._percentsDiv.append(this._noneDiv);\n\n      {\n        this._noneLabel = document.createElement(\"label\");\n\n        this._noneLabel.setAttribute(\"class\", \"labelDetail\"); //this._noneLabel.addEventListener(\"click\", this.GetNoneNullAttributes.bind(this));\n\n\n        this._noneDiv.append(this._noneLabel);\n      } //Recommended\n\n      this._recommendedDiv = document.createElement(\"div\");\n\n      this._recommendedDiv.setAttribute(\"class\", \"divRecommended\");\n\n      this._percentsDiv.append(this._recommendedDiv);\n\n      {\n        this._recommendedLabel = document.createElement(\"label\");\n\n        this._recommendedLabel.setAttribute(\"class\", \"labelDetail\"); //this._recommendedLabel.addEventListener(\"click\", this.GetRecommendedNullAttributes.bind(this));\n\n\n        this._recommendedDiv.append(this._recommendedLabel);\n      } //Required\n\n      this._requiredDiv = document.createElement(\"div\");\n\n      this._requiredDiv.setAttribute(\"class\", \"divRequired\");\n\n      this._percentsDiv.append(this._requiredDiv);\n\n      {\n        this._requiredLabel = document.createElement(\"label\");\n\n        this._requiredLabel.setAttribute(\"class\", \"labelDetail\"); //this._requiredLabel.addEventListener(\"click\", this.GetRequiredNullAttributes.bind(this));\n\n\n        this._requiredDiv.append(this._requiredLabel);\n      }\n    } //Break Row\n\n    var br = document.createElement(\"br\");\n\n    this._container.append(br);\n\n    this._container.append(br); //Attributes Div\n\n\n    this._attributesDiv = document.createElement(\"div\");\n\n    this._attributesDiv.setAttribute(\"class\", \"divAttributes\");\n\n    this._container.append(this._attributesDiv);\n  };\n\n  CompleteForm.prototype.AssociateValues = function () {\n    if (this.GetAllAttributes() == 0) return; //% Completed\n\n    this._geralPercentLabel.innerText = ((1 - this.GetNullAttributes() / this.GetAllAttributes()) * 100).toFixed(0).toString() + \" % Completed\"; //x/y by Required Level\n    //this._noneLabel.innerText = this._noneNotNulls.length + \"/\" + this.GetNones();\n\n    this._noneDiv.title = this.GetNones() - this._noneNotNulls.length + \" null attribute(s)\"; //this._recommendedLabel.innerText = this._recommendedNotNulls.length + \"/\" + this.GetRecommendeds();\n\n    this._recommendedDiv.title = this.GetRecommendeds() - this._recommendedNotNulls.length + \" null attribute(s)\"; //this._requiredLabel.innerText = this._requiredNotNulls.length + \"/\" + this.GetRequireds();\n\n    this._requiredDiv.title = this.GetRequireds() - this._requiredNotNulls.length + \" null attribute(s)\"; //% by Required Level\n\n    this._noneDiv.style.width = (this.GetNones() / this.GetAllAttributes() * 100).toString().replace(\",\", \".\") + \"%\";\n    this._recommendedDiv.style.width = (this.GetRecommendeds() / this.GetAllAttributes() * 100).toString().replace(\",\", \".\") + \"%\";\n    this._requiredDiv.style.width = (this.GetRequireds() / this.GetAllAttributes() * 100).toString().replace(\",\", \".\") + \"%\";\n  };\n\n  CompleteForm.prototype.GetAllAttributes = function () {\n    return this._requiredNulls.length + this._recommendedNulls.length + this._noneNulls.length + this._requiredNotNulls.length + this._recommendedNotNulls.length + this._noneNotNulls.length;\n  };\n\n  CompleteForm.prototype.GetNullAttributes = function () {\n    return this._requiredNulls.length + this._recommendedNulls.length + this._noneNulls.length;\n  };\n\n  CompleteForm.prototype.GetNones = function () {\n    return this._noneNulls.length + this._noneNotNulls.length;\n  };\n\n  CompleteForm.prototype.GetRecommendeds = function () {\n    return this._recommendedNulls.length + this._recommendedNotNulls.length;\n  };\n\n  CompleteForm.prototype.GetRequireds = function () {\n    return this._requiredNulls.length + this._requiredNotNulls.length;\n  };\n\n  CompleteForm.prototype.GetNoneNullAttributes = function () {\n    this.RenderAttributes(this._noneNulls.map(function (m) {\n      return m.getName();\n    }), \"grey\");\n  };\n\n  CompleteForm.prototype.GetRecommendedNullAttributes = function () {\n    this.RenderAttributes(this._recommendedNulls.map(function (m) {\n      return m.getName();\n    }), \"dodgerblue\");\n  };\n\n  CompleteForm.prototype.GetRequiredNullAttributes = function () {\n    this.RenderAttributes(this._requiredNulls.map(function (m) {\n      return m.getName();\n    }), \"tomato\");\n  };\n\n  CompleteForm.prototype.RenderAttributes = function (attributeLogicalNames, backgroundColor) {\n    //Clear Attribute List\n    this.ClearAttributes(); //Set Color\n\n    this._attributesDiv.style.backgroundColor = backgroundColor; //Attribute List\n\n    var ul;\n    ul = document.createElement(\"ul\");\n\n    this._attributesDiv.append(ul);\n\n    var items;\n    items = new Array(); //Attribute Item\n\n    for (var index = 0; index < attributeLogicalNames.length; index++) {\n      var attributeItem = attributeLogicalNames[index];\n      var li = void 0;\n      li = document.createElement(\"li\");\n      li.id = attributeItem;\n      li.innerText = Xrm.Page.getControl(attributeItem) != null ? Xrm.Page.getControl(attributeItem).getLabel() : attributeItem;\n      li.addEventListener(\"click\", this.SetFocus.bind(this, li.id));\n      items.push(li);\n    } //Sort By DisplayName\n\n\n    items = items.sort(function compare(a, b) {\n      if (a.innerText < b.innerText) {\n        return -1;\n      }\n\n      if (a.innerText > b.innerText) {\n        return 1;\n      }\n\n      return 0;\n    }); //Insert Itens\n\n    for (var index = 0; index < items.length; index++) {\n      var li = items[index];\n      ul.append(li);\n    }\n  };\n\n  CompleteForm.prototype.SetFocus = function (attribute) {\n    alert(attribute);\n    this.ClearAttributes(); //Xrm.Page.getControl(attribute)!.setFocus();\n  };\n\n  CompleteForm.prototype.ClearAttributes = function () {\n    while (this._attributesDiv.firstChild) {\n      this._attributesDiv.removeChild(this._attributesDiv.firstChild);\n    }\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  CompleteForm.prototype.updateView = function (context) {};\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  CompleteForm.prototype.getOutputs = function () {\n    return {};\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  CompleteForm.prototype.destroy = function () {// Add code to cleanup control if necessary\n  };\n\n  return CompleteForm;\n}();\n\nexports.CompleteForm = CompleteForm;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./CompleteForm/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('VinnyBControls.CompleteForm', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.CompleteForm);
} else {
	var VinnyBControls = VinnyBControls || {};
	VinnyBControls.CompleteForm = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.CompleteForm;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}