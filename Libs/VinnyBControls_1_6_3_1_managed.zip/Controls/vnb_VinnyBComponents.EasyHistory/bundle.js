var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./EasyHistory/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./EasyHistory/ActionContract.ts":
/*!***************************************!*\
  !*** ./EasyHistory/ActionContract.ts ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar ActionContract =\n/** @class */\nfunction () {\n  function ActionContract() {}\n  /**\r\n   * name\r\n   */\n\n\n  ActionContract.prototype.getMetadata = function () {};\n\n  return ActionContract;\n}();\n\nexports.ActionContract = ActionContract;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./EasyHistory/ActionContract.ts?");

/***/ }),

/***/ "./EasyHistory/MyPropertyHelper.ts":
/*!*****************************************!*\
  !*** ./EasyHistory/MyPropertyHelper.ts ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar MyPropertyHelper =\n/** @class */\nfunction () {\n  function MyPropertyHelper() {}\n\n  MyPropertyHelper.prototype.AttributeLogicalName = function (property) {\n    var AttributeLogicalName = \"\";\n\n    switch (property.type) {\n      case \"Whole.None\":\n        AttributeLogicalName = property.attributes.LogicalName;\n        break;\n\n      case \"TwoOptions\":\n        AttributeLogicalName = property.attributes.LogicalName;\n        break;\n\n      case \"DateAndTime.DateOnly\":\n      case \"DateAndTime.DateAndTime\":\n        AttributeLogicalName = property.attributes.LogicalName;\n        break;\n\n      case \"Decimal\":\n      case \"Currency\":\n        AttributeLogicalName = property.attributes.LogicalName;\n        break;\n\n      case \"FP\":\n        AttributeLogicalName = property.attributes.LogicalName;\n        break;\n\n      case \"Multiple\":\n        AttributeLogicalName = property.attributes.LogicalName;\n        break;\n\n      case \"OptionSet\":\n        AttributeLogicalName = property.attributes.LogicalName;\n        break;\n\n      case \"SingleLine.Email\":\n      case \"SingleLine.Text\":\n      case \"SingleLine.TextArea\":\n      case \"SingleLine.URL\":\n      case \"SingleLine.Ticker\":\n      case \"SingleLine.Phone\":\n        AttributeLogicalName = property.attributes.LogicalName;\n        break;\n\n      default:\n        break;\n    }\n\n    return AttributeLogicalName;\n  };\n\n  MyPropertyHelper.prototype.AttributeDisplayName = function (property) {\n    var AttributeDisplayName = \"\";\n\n    switch (property.type) {\n      case \"Whole.None\":\n        AttributeDisplayName = property.attributes.DisplayName;\n        break;\n\n      case \"TwoOptions\":\n        AttributeDisplayName = property.attributes.DisplayName;\n        break;\n\n      case \"DateAndTime.DateOnly\":\n      case \"DateAndTime.DateAndTime\":\n        AttributeDisplayName = property.attributes.DisplayName;\n        break;\n\n      case \"Decimal\":\n      case \"Currency\":\n        AttributeDisplayName = property.attributes.DisplayName;\n        break;\n\n      case \"FP\":\n        AttributeDisplayName = property.attributes.DisplayName;\n        break;\n\n      case \"Multiple\":\n        AttributeDisplayName = property.attributes.DisplayName;\n        break;\n\n      case \"OptionSet\":\n        AttributeDisplayName = property.attributes.DisplayName;\n        break;\n\n      case \"SingleLine.Email\":\n      case \"SingleLine.Text\":\n      case \"SingleLine.TextArea\":\n      case \"SingleLine.URL\":\n      case \"SingleLine.Ticker\":\n      case \"SingleLine.Phone\":\n        AttributeDisplayName = property.attributes.DisplayName;\n        break;\n\n      default:\n        break;\n    }\n\n    return AttributeDisplayName;\n  };\n\n  return MyPropertyHelper;\n}();\n\nexports.MyPropertyHelper = MyPropertyHelper;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./EasyHistory/MyPropertyHelper.ts?");

/***/ }),

/***/ "./EasyHistory/index.ts":
/*!******************************!*\
  !*** ./EasyHistory/index.ts ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar ActionContract_1 = __webpack_require__(/*! ./ActionContract */ \"./EasyHistory/ActionContract.ts\");\n\nvar MyPropertyHelper_1 = __webpack_require__(/*! ./MyPropertyHelper */ \"./EasyHistory/MyPropertyHelper.ts\");\n\nvar EasyHistory =\n/** @class */\nfunction () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function EasyHistory() {\n    this._myPropertyHelper = new MyPropertyHelper_1.MyPropertyHelper();\n  }\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='starndard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  EasyHistory.prototype.init = function (context, notifyOutputChanged, state, container) {\n    //Context\n    this._context = context;\n    this._notifyOutputChanged = notifyOutputChanged; //Atribute\n\n    this._attributeLogicalName = this._myPropertyHelper.AttributeLogicalName(this._context.parameters.attribute);\n    this._attributeDisplayName = this._myPropertyHelper.AttributeDisplayName(this._context.parameters.attribute); //Core\n\n    this._container = document.createElement(\"div\");\n\n    this._container.setAttribute(\"class\", \"Container\");\n\n    container.append(this._container); //Main\n    //Core.Button.Input\n\n    this._historyButton = document.createElement(\"button\");\n\n    this._historyButton.setAttribute(\"type\", \"button\");\n\n    if (Xrm.Page.ui.getFormType() != 1\n    /* Create */\n    ) {\n        this._historyButton.setAttribute(\"class\", \"Retrieve\");\n\n        this._historyButton.disabled = false;\n      } else {\n      this._historyButton.setAttribute(\"class\", \"RetrieveDisabled\");\n\n      this._historyButton.disabled = true;\n    }\n\n    this._historyButton.innerText = \"Show history of \" + this._attributeDisplayName;\n\n    this._historyButton.addEventListener(\"click\", this.ShowHistory.bind(this));\n\n    this._container.append(this._historyButton); //Core.History\n\n\n    this._historyContainer = document.createElement(\"div\");\n\n    this._historyContainer.setAttribute(\"class\", \"HiddenHistory\");\n\n    this._historyButton.append(this._historyContainer);\n  };\n\n  EasyHistory.prototype.ShowHistory = function () {\n    if (this._historyContainer.className == \"HiddenHistory\") {\n      //Get Attribute History\n      this.RetrieveHistory(); //this.RetrieveHistoryMOC();\n\n      this._historyContainer.setAttribute(\"class\", \"VisibleHistory\");\n    } else {\n      this.ClearHistory();\n\n      this._historyContainer.setAttribute(\"class\", \"HiddenHistory\");\n    }\n  };\n\n  EasyHistory.prototype.RetrieveHistoryMOC = function () {\n    var A = this.CreateHistoryParamagraph(\"A\", \"8/12/2019 5:26:11 PM\", \"Vinicius Basile\");\n    var B = this.CreateHistoryParamagraph(\"B\", \"8/12/2019 5:26:11 PM\", \"Vinicius Basile\");\n    var C = this.CreateHistoryParamagraph(\"C\", \"8/12/2019 5:26:11 PM\", \"Vinicius Basile\");\n    this.AddHistoryRecord(A);\n    this.AddHistoryRecord(B);\n    this.AddHistoryRecord(C);\n  };\n\n  EasyHistory.prototype.RetrieveHistory = function () {\n    var request = new ActionContract_1.ActionContract();\n    request.EntityLogicalName = Xrm.Page.data.entity.getEntityName();\n    request.EntityId = Xrm.Page.data.entity.getId().replace(\"{\", \"\").replace(\"}\", \"\");\n    request.AttributeLogicalName = this._attributeLogicalName;\n\n    request.getMetadata = function () {\n      return {\n        boundParameter: null,\n        parameterTypes: {\n          \"EntityLogicalName\": {\n            \"typeName\": \"Edm.String\",\n            \"structuralProperty\": 1\n          },\n          \"EntityId\": {\n            \"typeName\": \"Edm.String\",\n            \"structuralProperty\": 1\n          },\n          \"AttributeLogicalName\": {\n            \"typeName\": \"Edm.String\",\n            \"structuralProperty\": 1\n          }\n        },\n        operationType: 0,\n        operationName: \"vnb_RetrieveAttributeHistory\"\n      };\n    };\n\n    var self = this;\n    Xrm.WebApi.online.execute(request).then(function (result) {\n      if (result.ok) {\n        self.FetchStream(self, result.body);\n      }\n    }, function (error) {\n      Xrm.Utility.alertDialog(error.message, function () {});\n    });\n  };\n\n  EasyHistory.prototype.FetchStream = function (caller, stream) {\n    var reader = stream.getReader();\n    var text;\n    text = \"\";\n    reader.read().then(function processText(_a) {\n      var done = _a.done,\n          value = _a.value;\n\n      if (done) {\n        var content = JSON.parse(text);\n        var historyDetails = JSON.parse(content.History);\n\n        for (var _i = 0, historyDetails_1 = historyDetails; _i < historyDetails_1.length; _i++) {\n          var historyDetail = historyDetails_1[_i];\n          caller.AddHistoryRecord(caller.CreateHistoryParamagraph(historyDetail.Value, historyDetail.ModifiedOn, historyDetail.User));\n        }\n\n        return;\n      }\n\n      if (value) text += new TextDecoder(\"utf-8\").decode(value);\n      reader.read().then(processText);\n    });\n  };\n\n  EasyHistory.prototype.CreateHistoryParamagraph = function (historyValue, modifiedOn, userName) {\n    var div;\n    div = document.createElement(\"div\");\n    div.setAttribute(\"class\", \"HistoryRecord\");\n    var elementHistory;\n    elementHistory = document.createElement(\"p\");\n    elementHistory.setAttribute(\"class\", \"HistoryValue\");\n    elementHistory.innerHTML = historyValue;\n    div.append(elementHistory);\n    var elementDetail;\n    elementDetail = document.createElement(\"p\");\n    elementDetail.setAttribute(\"class\", \"HistoryDetail\");\n    elementDetail.innerHTML = userName + \": \" + modifiedOn;\n    div.append(elementDetail);\n    return div;\n  };\n\n  EasyHistory.prototype.AddHistoryRecord = function (element) {\n    this._historyContainer.appendChild(element);\n  };\n\n  EasyHistory.prototype.ClearHistory = function () {\n    while (this._historyContainer.firstChild) {\n      this._historyContainer.removeChild(this._historyContainer.firstChild);\n    }\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  EasyHistory.prototype.updateView = function (context) {};\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  EasyHistory.prototype.getOutputs = function () {\n    return {};\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  EasyHistory.prototype.destroy = function () {// Add code to cleanup control if necessary\n  };\n\n  return EasyHistory;\n}();\n\nexports.EasyHistory = EasyHistory;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./EasyHistory/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('VinnyBComponents.EasyHistory', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.EasyHistory);
} else {
	var VinnyBComponents = VinnyBComponents || {};
	VinnyBComponents.EasyHistory = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.EasyHistory;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}