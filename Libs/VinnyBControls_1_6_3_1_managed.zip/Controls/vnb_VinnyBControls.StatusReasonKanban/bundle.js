var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./StatusReasonKanban/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./StatusReasonKanban/ActionContract.ts":
/*!**********************************************!*\
  !*** ./StatusReasonKanban/ActionContract.ts ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar ActionContract =\n/** @class */\nfunction () {\n  function ActionContract() {}\n\n  ActionContract.prototype.getMetadata = function () {};\n\n  return ActionContract;\n}();\n\nexports.ActionContract = ActionContract;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./StatusReasonKanban/ActionContract.ts?");

/***/ }),

/***/ "./StatusReasonKanban/UpdateRequest.ts":
/*!*********************************************!*\
  !*** ./StatusReasonKanban/UpdateRequest.ts ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar UpdateRequest =\n/** @class */\nfunction () {\n  function UpdateRequest() {}\n\n  return UpdateRequest;\n}();\n\nexports.UpdateRequest = UpdateRequest;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./StatusReasonKanban/UpdateRequest.ts?");

/***/ }),

/***/ "./StatusReasonKanban/index.ts":
/*!*************************************!*\
  !*** ./StatusReasonKanban/index.ts ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar ActionContract_1 = __webpack_require__(/*! ./ActionContract */ \"./StatusReasonKanban/ActionContract.ts\");\n\nvar UpdateRequest_1 = __webpack_require__(/*! ./UpdateRequest */ \"./StatusReasonKanban/UpdateRequest.ts\");\n\nvar StatusReasonKanban =\n/** @class */\nfunction () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function StatusReasonKanban() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='starndard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  StatusReasonKanban.prototype.init = function (context, notifyOutputChanged, state, container) {\n    this._entityType = context.parameters.DataSet.getTargetEntityType();\n    this._entitySetName = this.RetrieveEntityMetada(this._entityType); //Table\n\n    this._container = document.createElement(\"table\");\n\n    this._container.setAttribute(\"class\", \"Container\");\n\n    container.append(this._container); //Tds - Generate dynamic view by statusCode\n\n    this.RetrieveOptionSetMetadata(this._entityType);\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  StatusReasonKanban.prototype.updateView = function (context) {\n    //If the view is loaded\n    if (!context.parameters.DataSet.loading) {\n      this._context = context;\n      this.RenderCards();\n    }\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  StatusReasonKanban.prototype.getOutputs = function () {\n    return {};\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  StatusReasonKanban.prototype.destroy = function () {};\n  /**\r\n   * Get StatusReason metadata\r\n   * @param EntityLogicalName\r\n   */\n\n\n  StatusReasonKanban.prototype.RetrieveOptionSetMetadata = function (EntityLogicalName) {\n    var request = new ActionContract_1.ActionContract();\n    request.EntityLogicalName = EntityLogicalName;\n\n    request.getMetadata = function () {\n      return {\n        boundParameter: null,\n        parameterTypes: {\n          \"EntityLogicalName\": {\n            \"typeName\": \"Edm.String\",\n            \"structuralProperty\": 1\n          }\n        },\n        operationType: 0,\n        operationName: \"vnb_RetrieveOptionSetMetadata\"\n      };\n    };\n\n    var self = this;\n    Xrm.WebApi.online.execute(request).then(function (result) {\n      if (result.ok) {\n        self.FetchStream(self, result.body);\n      }\n    }, function (error) {\n      Xrm.Utility.alertDialog(error.message, function () {});\n    });\n  };\n\n  StatusReasonKanban.prototype.FetchStream = function (caller, stream) {\n    var reader = stream.getReader();\n    var text;\n    text = \"\";\n    reader.read().then(function processText(_a) {\n      var done = _a.done,\n          value = _a.value;\n\n      if (done) {\n        var content = JSON.parse(text);\n        caller._options = JSON.parse(content.OptionSetMetadata);\n        caller.RenderKanban();\n        caller.RenderCards();\n        return;\n      }\n\n      if (value) text += new TextDecoder(\"utf-8\").decode(value);\n      reader.read().then(processText);\n    });\n  };\n  /**\r\n   * Render options as a Kanban\r\n   */\n\n\n  StatusReasonKanban.prototype.RenderKanban = function () {\n    //Render a Undefined Option, if the the view don't has a StatusCode column the record will assigned to this DIV\n    this.UndefinedOption();\n\n    for (var index = 0; index < this._options.length; index++) {\n      //Get Option\n      var option = this._options[index]; //td\n\n      var tdOption = void 0;\n      tdOption = document.createElement(\"td\");\n      tdOption.setAttribute(\"class\", \"Option\");\n      tdOption.id = option.StateCode + \";\" + option.StatusCode;\n      tdOption.style.backgroundColor = option.Color != null ? option.Color : \"transparent\";\n      tdOption.addEventListener(\"dragover\", this.AllowDrop.bind(this));\n      tdOption.addEventListener(\"drop\", this.OnDrop.bind(this, tdOption));\n\n      this._container.append(tdOption); //label\n\n\n      var labelOption = void 0;\n      labelOption = document.createElement(\"label\");\n      labelOption.innerText = option.Label;\n      tdOption.append(labelOption);\n    }\n  };\n  /**\r\n   * Render the view records as cards on kanban\r\n   */\n\n\n  StatusReasonKanban.prototype.RenderCards = function () {\n    this.ClearContainer();\n    var columns = this.GetColumns(this._context);\n    this.CreateRecordDiv(this._context, columns);\n    this.HiddenUndefined();\n  };\n  /**\r\n   * Retrieve all columns in the view\r\n   * @param context\r\n   */\n\n\n  StatusReasonKanban.prototype.GetColumns = function (context) {\n    //alert(context.parameters.dataSet.columns.length);\n    //No columns\n    if (!context.parameters.DataSet.columns && context.parameters.DataSet.columns.length === 0) {\n      return [];\n    }\n\n    var columns = context.parameters.DataSet.columns.filter(function (columnItem) {\n      return columnItem.order >= 0;\n    }); // Sort those columns so that they will be rendered in order\n\n    columns.sort(function (a, b) {\n      return a.order - b.order;\n    });\n    return columns;\n  };\n  /**\r\n   * Create a DIV to represents the record\r\n   * @param context\r\n   * @param columns\r\n   */\n\n\n  StatusReasonKanban.prototype.CreateRecordDiv = function (context, columns) {\n    if (context.parameters.DataSet.sortedRecordIds.length > 0) {\n      var _loop_1 = function _loop_1(recordId) {\n        //ENTITY REFERENCE\n        var entityReference = context.parameters.DataSet.records[recordId].getNamedReference(); //DIV\n\n        var recordDiv;\n        recordDiv = document.createElement(\"div\");\n        recordDiv.setAttribute(\"class\", \"RecordGrab\");\n        recordDiv.id = recordId.toString();\n        recordDiv.setAttribute(\"entityType\", entityReference.entityType);\n        recordDiv.setAttribute(\"draggable\", true.toString());\n        recordDiv.addEventListener(\"dragstart\", this_1.OnDrag.bind(this_1, recordDiv));\n        recordDiv.addEventListener(\"dblclick\", this_1.OpenRecord.bind(this_1, entityReference.entityType, recordDiv.id));\n        var statusCode = \"\"; //Columns in view / value\n\n        columns.forEach(function (column, index) {\n          if (column.name == \"statuscode\") statusCode = context.parameters.DataSet.records[recordId].getValue(column.name).toString();else {\n            var value = context.parameters.DataSet.records[recordId].getFormattedValue(column.name);\n\n            if (value) {\n              //P\n              var attributeValue = document.createElement(\"p\");\n              attributeValue.textContent = value;\n              recordDiv.append(attributeValue);\n            }\n          }\n        }); //Select TD\n\n        this_1.DefineParent(statusCode).append(recordDiv);\n      };\n\n      var this_1 = this; //RECORD\n\n      for (var _i = 0, _a = context.parameters.DataSet.sortedRecordIds; _i < _a.length; _i++) {\n        var recordId = _a[_i];\n\n        _loop_1(recordId);\n      }\n    }\n  };\n  /**\r\n   * Define where the card (record) will be displayed\r\n   * @param statusCode option number\r\n   */\n\n\n  StatusReasonKanban.prototype.DefineParent = function (statusCode) {\n    if (statusCode) {\n      var options = document.getElementsByClassName(\"Option\");\n\n      for (var index = 0; index < options.length; index++) {\n        var option = options[index];\n        var re = \";\" + statusCode;\n        if (option.id.search(re) != -1) return option;\n      }\n\n      return this._undefinedOption;\n    } else return this._undefinedOption;\n  };\n  /**\r\n   * Render a stage for records out of option's range\r\n   */\n\n\n  StatusReasonKanban.prototype.UndefinedOption = function () {\n    //td\n    var tdOption;\n    tdOption = document.createElement(\"td\");\n    tdOption.setAttribute(\"class\", \"Option\");\n    tdOption.id = \"undefined\";\n    tdOption.style.backgroundColor = \"transparent\"; //Append\n\n    this._container.append(tdOption);\n\n    this._undefinedOption = tdOption;\n  };\n  /**\r\n   * Hidden the undefined stage, if it hasn't cards (records)\r\n   */\n\n\n  StatusReasonKanban.prototype.HiddenUndefined = function () {\n    if (this._undefinedOption.childElementCount == 0) {\n      this._undefinedOption.style.visibility = \"hidden\";\n      this._undefinedOption.style.width = \"0px\";\n    }\n  };\n  /**\r\n   * Clear all components by Option\r\n   */\n\n\n  StatusReasonKanban.prototype.ClearContainer = function () {\n    var options = document.getElementsByClassName(\"Option\");\n\n    for (var index = 0; index < options.length; index++) {\n      var option = options[index];\n\n      while (option.lastChild) {\n        var element = option.lastChild;\n        if (element.tagName === \"LABEL\") break;else option.removeChild(element);\n      }\n    }\n  };\n  /**\r\n   * Change the Status Record\r\n   */\n\n\n  StatusReasonKanban.prototype.SetStateRequest = function (td) {\n    //Workaround, sometimes the record don't have the entitytype\n    var entityType = this._selectedRecord.getAttribute(\"entityType\");\n\n    if (!entityType) entityType = this._entityType;\n    var updateRequest;\n    updateRequest = new UpdateRequest_1.UpdateRequest();\n    updateRequest.statecode = Number(td.id.split(\";\")[0]);\n    updateRequest.statuscode = Number(td.id.split(\";\")[1]);\n    var self = this;\n    var req = new XMLHttpRequest();\n    req.open(\"PATCH\", Xrm.Page.context.getClientUrl() + \"/api/data/v9.1/\" + this._entitySetName + \"(\" + this._selectedRecord.id + \")\", true);\n    req.setRequestHeader(\"OData-MaxVersion\", \"4.0\");\n    req.setRequestHeader(\"OData-Version\", \"4.0\");\n    req.setRequestHeader(\"Accept\", \"application/json\");\n    req.setRequestHeader(\"Content-Type\", \"application/json; charset=utf-8\");\n\n    req.onreadystatechange = function () {\n      if (this.readyState === 4) {\n        req.onreadystatechange = null;\n\n        if (this.status === 204) {\n          td.append(self._selectedRecord);\n          self._selectedRecord = document.createElement(\"div\");\n        } else {\n          var exception = JSON.parse(this.responseText);\n          var errorMessage = exception.error.message;\n          alert(errorMessage);\n        }\n      }\n    };\n\n    req.send(JSON.stringify(updateRequest));\n  };\n  /**\r\n  * Retrieve EntitySetName\r\n  * @param entityLogicalName\r\n  */\n\n\n  StatusReasonKanban.prototype.RetrieveEntityMetada = function (entityLogicalName) {\n    var entitySet;\n    entitySet = \"\";\n    var req = new XMLHttpRequest();\n    req.open(\"GET\", Xrm.Page.context.getClientUrl() + \"/api/data/v9.1/\" + \"EntityDefinitions(LogicalName='\" + entityLogicalName + \"')?$select=EntitySetName\", false);\n    req.setRequestHeader(\"Accept\", \"application/json\");\n    req.setRequestHeader(\"Content-Type\", \"application/json; charset=utf-8\");\n    req.setRequestHeader(\"OData-MaxVersion\", \"4.0\");\n    req.setRequestHeader(\"OData-Version\", \"4.0\");\n\n    req.onreadystatechange = function () {\n      if (this.readyState === 4) {\n        req.onreadystatechange = null;\n\n        if (this.status === 200) {\n          var result = JSON.parse(this.response);\n          entitySet = result.EntitySetName;\n        } else {\n          entitySet = \"\";\n        }\n      }\n    };\n\n    req.send();\n    return entitySet;\n  };\n  /**\r\n   * Double click on Cards\r\n   * @param entityId\r\n   */\n\n\n  StatusReasonKanban.prototype.OpenRecord = function (entityType, entityId) {\n    if (!entityType) entityType = this._entityType;\n    Xrm.Utility.openEntityForm(entityType, entityId, {});\n  };\n\n  StatusReasonKanban.prototype.AllowDrop = function (event) {\n    event.preventDefault();\n  };\n\n  StatusReasonKanban.prototype.OnDrop = function (td) {\n    if (this._selectedRecord && this._selectedRecord.parentElement && this._selectedRecord.id) {\n      this._selectedRecord.setAttribute(\"class\", \"RecordGrab\");\n\n      this.SetStateRequest(td);\n    }\n  };\n\n  StatusReasonKanban.prototype.OnDrag = function (record) {\n    record.setAttribute(\"class\", \"RecordGrabbing\");\n    this._selectedRecord = record;\n  };\n\n  return StatusReasonKanban;\n}();\n\nexports.StatusReasonKanban = StatusReasonKanban;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./StatusReasonKanban/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('VinnyBControls.StatusReasonKanban', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.StatusReasonKanban);
} else {
	var VinnyBControls = VinnyBControls || {};
	VinnyBControls.StatusReasonKanban = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.StatusReasonKanban;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}